#include <iostream>
#include <string>
#include "file_plus.hpp"
using namespace std;
using namespace file_plus;
string paths;
void coutcolor(string c,string d,char e)
{
	cout<<"\033["+c+";"+d+"m"<<e<<"\033[0m";
}
int main()
{
	while(true)
	{
		system("clear");
		cout<<"\033[1;3;30;47mSky Terminal Picture Viewer for Linux                                                                                                                           \033[0m";
		cout<<"Hello!Welcome to Terminal Picture Viewer for Linux.Please enter the file path.(*stpvlf,Sky Terminal Pictrue Viewer for Linux File)"<<endl;
		while(true)
		{
			cin>>paths;
			if(paths=="/stop")
			{
				return 0;
			}
			else if(File_exist(String_to_path(paths)))
			{
				break;
			}
			else{
				cout<<"The path isn't exist."<<endl;
			}
		}
		cin.get();
		PATH pathses=String_to_path(paths);
		int fl=File_line(pathses);
		for(int i=1;i<=fl;i++)
		{
			string tl=File_read(pathses,i);
			int l=(tl.length()+1)/5;
			for(int j=0;j<l;j++)
			{
				int a=tl[j*5]-48;
				int b=tl[j*5+1]-48;
				int d=tl[j*5+2]-48;
				int e=tl[j*5+3]-48;
				int c=10*a+b;
				int f=10*d+e;
				cout<<"\033[4;"+to_string(c)+";"+to_string(f)+"m"<<tl[j*5+4]<<"\033[0m";
			}
			cout<<endl;
		}
		cin.get();
	}
	return 0;
}
