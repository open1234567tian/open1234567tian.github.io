// file:file_plus.hpp

// brief:The expansion of C plus plus fstream and filesystem
// author:epii
// date:Oh,I forgot...

#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <filesystem>

namespace fs=std::filesystem;

#define _EPII_FILE_PLUS_HPP_
#if __cplusplus >= 201703L || (defined(_MSC_VER) && _MSVC_LANG >= 201703L)
namespace file_plus {

	enum class ftype{file,folder,all};

	bool file_exist(std::string paths,ftype type)
	{
		if (type == ftype::file)
		{
			std::fstream f(paths);
			if (f.good())
			{
				return true;
			}
			return false;
		}
		else if(type==ftype::folder){
			return fs::is_directory(paths);
		}
		else {
			return fs::exists(paths);
		}
	}

	std::string file_read(std::string paths, int line)
	{
		std::ifstream f(paths);
		if (!file_exist(paths,ftype::file))
		{
			return "File_Plus_Error:file does not exist!";
		}
		int i = 1;
		std::string str;
		while (getline(f, str))
		{
			if (i >= line)
			{
				break;
			}
			i++;
		}
		if (i < line)
		{
			return "File_Plus_Error:The document does not have line " + std::to_string(line) + "!!!";
		}
		return str;
	}

	bool file_new(std::string paths,ftype type)
	{
		if (type == ftype::file)
		{
			std::ofstream f(paths);
			if (f.is_open())
			{
				f.close();
				return true;
			}
		}
		else if (type == ftype::folder)
		{
			fs::path pt = paths;
			if (file_exist(paths, ftype::all))
			{
				return false;
			}
			if (!file_exist(pt.parent_path().string(), ftype::folder))
			{
				return false;
			}
			if (!fs::create_directory(paths))
			{
				return false;
			}
			return true;
		}
		else {
			return false;
		}
	}

	bool file_change(std::string paths, std::string content)
	{
		if (!file_exist(paths,ftype::file))
		{
			return false;
		}
		std::fstream f(paths, std::ios::out);
		if (f.is_open())
		{
			f << content;
			f.close();
			return true;
		}
		return false;
	}

	bool file_delete(std::string paths,ftype type)
	{
		if (file_exist(paths, type))
		{
			fs::remove_all(paths);
		}
		if (file_exist(paths, type))
		{
			return false;
		}
		return true;
	}

	std::string what_os()
	{
#if _WIN32
#if _WIN64
		return "Windows64";
#else
		return "Windows32";
#endif
#elif  __linux__
#if __ANDROID__
		return "Android";
#else
		return "Linux";
#endif
#elif __APPLE__
#if TARGET_OS_IPHONE
		return "IOS";
#elif TARGET_OS_MAC
		return "MacOS";
#else
		return "OtherApple";
#endif
#elif __HARMONYOS__
		return "HarmonyOS";
#else
		return "Other";
#endif
	}

	bool rename_file(std::string paths, std::string newname)
	{
		fs::path pt = paths;
		if (!file_exist(paths,ftype::all))
		{
			return false;
		}
		fs::path ls = pt.parent_path() / newname;
		rename(pt, ls);
		if (!file_exist(ls.string(),ftype::all))
		{
			return false;
		}
		return true;
	}

	bool move_file(std::string old_paths, std::string new_paths)
	{
		if (!file_exist(old_paths,ftype::file) || !file_exist(new_paths,ftype::folder))
		{
			return false;
		}
		rename(old_paths.c_str(), new_paths.c_str());
		if (!file_exist(new_paths,ftype::all))
		{
			return false;
		}
		return true;
	}

	int num_file_in_folder(std::string dir, ftype type)
	{
		fs::path dirpath = dir;
		if (file_exist(dir, ftype::folder))
		{
			int num = 0;
			for (auto tf : fs::directory_iterator(dirpath))
			{
				if (file_exist(tf.path().string(), type))
				{
					num++;
				}
			}
			return num;
		}
		else {
			return 0;
		}
	}

	std::string numth_file_in_folder(std::string dir,int numth, ftype type)
	{
		fs::path dirpath = dir;
		if (file_exist(dir, ftype::folder))
		{
			int num = 0;
			for (auto tf : fs::directory_iterator(dirpath))
			{
				if (file_exist(tf.path().string(), type))
				{
					num++;
				}
				if (num == numth)
				{
					return tf.path().filename().string();
				}
			}
			return "There are no "+std::to_string(numth) + " files in the folder!!!";
		}
		else {
			return "File_Plus_Error:file does not exist!";
		}
	}

}
#endif
